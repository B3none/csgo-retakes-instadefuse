# InstaDefuse
Allows a CT to instantly defuse the bomb when all Ts are dead and nothing can prevent the defusal.

It's worth noting that this will work on literally any server it's just primarily been used by the Retakes / Executes communities!

# Installation
Add the latest compiled version of the `retakes-instadefuse.smx` into your `addons/sourcemod/plugins/` folder.

The latest version is listed on the [releases tab](https://github.com/b3none/retakes-instadefuse/releases)

# Author
Alex Blackham - Developer and Maintainer - [B3none](https://github.com/b3none/)
